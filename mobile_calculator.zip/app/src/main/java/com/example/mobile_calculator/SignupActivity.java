package com.example.mobile_calculator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class SignupActivity extends AppCompatActivity {
    Button signup;
    Button cancel;
    Button check;
    EditText new_id;
    EditText new_pw;
    EditText new_name;
    EditText new_hp;
    EditText new_address;
    RadioGroup radioGroup;
    RadioButton accept,decline;
    int overlap = 0;
    int accep = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        cancel=findViewById(R.id.cancel);
        signup=findViewById(R.id.correct);
        new_id=findViewById(R.id.new_id);
        new_pw=findViewById(R.id.new_pw);
        check=findViewById(R.id.check);
        radioGroup=findViewById(R.id.radioGroup);
        accept=findViewById(R.id.accept);
        decline=findViewById(R.id.decline);
        new_name=findViewById(R.id.new_name);
        new_hp=findViewById(R.id.new_hp);
        new_address=findViewById(R.id.new_address);

        check.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String current_id = new_id.getText().toString();
                try {
                    FileInputStream fis = openFileInput("ID.txt");
                    BufferedReader buffer = new BufferedReader(new InputStreamReader(fis));
                    String str = buffer.readLine();
                    overlap=2;
                    while (str != null) {
                        if(current_id.equals(str)){
                            Toast.makeText(getApplicationContext(),"중복된 ID가 존재합니다.",Toast.LENGTH_LONG).show();
                            overlap=0;
                            break;
                        }
                        overlap =1;
                        str = buffer.readLine();
                    }
                    Toast.makeText(getApplicationContext(),"사용 가능한 ID입니다.",Toast.LENGTH_LONG).show();
                    buffer.close();
                }
                catch (Exception e) { e.printStackTrace(); }
            }
        });

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.accept:
                        accep=1;
                        break;
                    case R.id.decline:
                        accep=0;
                        break;
                }
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override    // 입력한 데이터를 파일에 추가로 저장하기
            public void onClick(View v) {
                String id = new_id.getText().toString();
                String pw = new_pw.getText().toString();
                String name = new_name.getText().toString();
                String hp = new_hp.getText().toString();
                String address = new_address.getText().toString();

                if(id.equals("") || pw.equals("") || name.equals("") || hp.equals("") || address.equals("")){
                    Toast.makeText(getApplicationContext(), "모든 정보를 입력해주세요.", Toast.LENGTH_LONG).show();
                }
                else {
                    if (accep == 1) {
                        if (overlap == 1 || overlap == 2) {
                            try {
                                FileOutputStream fos = openFileOutput("ID.txt", Context.MODE_APPEND);
                                FileOutputStream fos1 = openFileOutput("PW.txt", Context.MODE_APPEND);
                                FileOutputStream fos2 = openFileOutput("name.txt", Context.MODE_APPEND);
                                FileOutputStream fos3 = openFileOutput("hp.txt", Context.MODE_APPEND);
                                FileOutputStream fos4 = openFileOutput("address.txt", Context.MODE_APPEND);
                                PrintWriter out = new PrintWriter(fos);
                                PrintWriter out1 = new PrintWriter(fos1);
                                PrintWriter out2 = new PrintWriter(fos2);
                                PrintWriter out3 = new PrintWriter(fos3);
                                PrintWriter out4 = new PrintWriter(fos4);
                                out.println(id);
                                out1.println(pw);
                                out2.println(name);
                                out3.println(hp);
                                out4.println(address);
                                out.close();
                                out1.close();
                                out2.close();
                                out3.close();
                                out4.close();
                                Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                                startActivity(intent);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else { Toast.makeText(getApplicationContext(), "아이디 중복체크를 해주세요.", Toast.LENGTH_LONG).show();}
                    }
                    else { Toast.makeText(getApplicationContext(), "약관에 동의해주세요.", Toast.LENGTH_LONG).show(); }
                }
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
